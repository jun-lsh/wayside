# Hack&Roll 2026 "Quack & Roll" badge I/O component library

Component library to interface with the Hack&Roll 2026 badge's LEDs and buttons
via the built-in GPIO expander.

## Usage example

See how the badge uses this library to make the LEDs light up based on the
inputs to the buttons
[in the main repository](https://github.com/nushackers/hnr26-badge-workshop).
