# AW9523 GPIO expander component library

Generic component library for the AW9523 GPIO expander, originally developed for
the
[Hack&Roll 2026 "Quack & Roll" badge](https://github.com/nushackers/hnr26-badge).
