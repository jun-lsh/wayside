#define NFC_PWR_PIN         GPIO_NUM_0 
#define NFC_SDA_PIN         GPIO_NUM_20  /* SDA pin */
#define NFC_SCL_PIN         GPIO_NUM_21  /* SCL pin */
#define NFC_FD_PIN          GPIO_NUM_1   /* Field Detect interrupt pin */
#define NFC_I2C_FREQ_HZ         100000 
